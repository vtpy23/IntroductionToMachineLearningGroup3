# Bàn giao StrictReview, 19/11/2026

Phiên bản mới giữ kết quả ba seed và thiết kế hiện có, bổ sung kiểm chứng và các phân tích nhẹ từ classifier đã lưu. **Không push GitHub trong đợt này. Không chạy lại backbone hoặc refit thí nghiệm lịch sử.**

- [PowerPoint mới](../milestone2_final/DSAL_Milestone2_Lab1_3Seeds_StrictReview_Final.pptx)
- [PDF mới](../milestone2_final/DSAL_Milestone2_Lab1_3Seeds_StrictReview_Final.pdf)
- [Bản tên 03.pptx cho Moodle](../milestone2_final/submission_strict_review/03.pptx)
- [Đánh giá nghiêm ngặt và rủi ro điểm](FINAL_STRICT_REVIEW.md)
- [Những vấn đề đã xử lý](CHANGES.md)
- [Yêu cầu giảng viên → slide](REQUIREMENTS_TO_SLIDES.md)
- [Kiểm chứng số liệu](NUMERICAL_VERIFICATION.md)
- [Thí nghiệm → script → config → run](EXPERIMENT_MAPPING.md)
- [Đánh giá Core scope](CORE_SCOPE_REVIEW.md)
- [Bảng audit protocol và reproduction gap](GAP_PROTOCOL_AUDIT.md)
- [Vấn đề còn mở / thí nghiệm đề xuất](BLOCKED_AND_FOLLOWUP.md)
- [Hướng dẫn chạy và cập nhật slide](RUNBOOK.md)
- [Bằng chứng kỹ thuật](evidence/)

Nguồn mới: `prepare_strict_content.py`, `layout_overrides.mjs`, `merge_strict.py`, `validate_and_finalize.py`; PptxGenJS entrypoint tại `../milestone2_final/build_strict_review.mjs`. Bản trước `3Seeds_Final.pptx` và các file thực nghiệm vẫn nguyên vẹn. Chart/workbook của bản trước giữ nguyên byte; chart sensitivity mới dùng dữ liệu đo thật, kèm SD mẫu và workbook có thể chỉnh sửa.

Điều kiện trước nộp: nhóm cho phép công bố revision mới để mọi số truy về GitHub; kiểm tra chấp nhận Core/Forge theo yêu cầu giảng viên; kiểm tra thông báo Moodle và tên nhóm ID 03. Không dùng đánh giá ước lượng như điểm chính thức hoặc xác nhận hoàn tất poster cuối.
